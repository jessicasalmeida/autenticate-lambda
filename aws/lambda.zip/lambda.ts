
import * as jwt from 'jsonwebtoken';
import * as dotenv from "dotenv";
import axios from 'axios';

dotenv.config();

interface CognitoJWT {
    iss: string;
    sub: string;
    token_use: string;
    exp: number;
    iat: number;
    username: string;
}

export async function login(event: any): Promise<any> {
    try {
        const { body } = event;
        const { username, password } = JSON.parse(body);
        
        // Autenticar o usuário no Cognito
        const authResponse = await authenticateUser(username, password);
        
        // Verificar se a autenticação foi bem-sucedida
        if (!authResponse || !authResponse.AuthenticationResult) {
            throw new Error('Authentication failed');
        }
        
        const { idToken, accessToken, expiresIn } = authResponse.AuthenticationResult;
        
        // Decodificar o token JWT
        const decoded = jwt.decode(idToken) as CognitoJWT;
        
        // Verificar se o token é válido e se é para o usuário correto
        if (decoded.token_use !== 'id') {
            throw new Error('Invalid token use');
        }
        
        // Aqui você pode adicionar outras verificações, como verificar o uso do token ou verificar se o token expirou
        
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                idToken,
                accessToken,
                expiresIn
            })
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 401,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: 'Authentication failed'
            })
        };
    }
}

// Função para autenticar o usuário no Cognito
async function authenticateUser(username: string, password: string) {
    try {
        const authResponse = await axios.post(`https://cognito-idp.${process.env.AWS_REGION}.amazonaws.com/${process.env.USER_POOL_ID}/oauth2/token`, null, {
            params: {
                grant_type: 'password',
                client_id: process.env.CLIENT_ID,
                username,
                password
            },
            auth: {
                username: process.env.CLIENT_ID as string,
                password: process.env.CLIENT_SECRET as string
            }
        });
        return authResponse.data;
    } catch (error) {
        console.error('Authentication error:', error);
        throw new Error('Authentication failed');
    }
}
function execSync(arg0: string) {
    throw new Error('Function not implemented.');
}

